import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.plaf.FontUIResource;

import PackagingMaterials.Reader;

/**
 * 
 */

/**
 * @author Anmol Kapoor
 * @version 1.0
 */
public class Writer {
	
	private BufferedImage background;
	private String csvPath;
	private Reader rdr;
	private JFrame semiConsole;
	private JPanel container;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new Writer();
	}
	
	/**
	 * Constructor
	 */
	public Writer() {
		background = new BufferedImage(900,900,BufferedImage.TYPE_INT_RGB);
		Graphics2D gbg = background.createGraphics();
		gbg.setPaint(Color.WHITE);
		gbg.fillRect(0,0,900,900);
		csvPath = "PackagingMaterials/data.csv";
		
		Enumeration<Object> keys = UIManager.getDefaults().keys();
		while(keys.hasMoreElements()) {
			Object key = keys.nextElement();
			Object value = UIManager.get(key);
			if(value instanceof FontUIResource) {
				UIManager.put(key, new FontUIResource("Serif", Font.PLAIN, 22));
			}
		}
		
		semiConsole = new JFrame("CEFE Writer SemiConsole");
		semiConsole.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		container = new JPanel();
		container.setLayout(new BorderLayout());

		getCsvContent();
		rdr = new Reader(false);
		updateView();
		
		semiConsole.pack();
		semiConsole.setResizable(false);
		semiConsole.setVisible(true);
	}
	
	/**
	 * Update the semiconsole view
	 */
	private void updateView() {
		// Testing Purposes Only
//		addObj(1, "Exit Program", 800,850,100,50, "exit");
//		addObj(1, "Do Nothing", 0,0,150,50, null);
//		addObj(2, "Exit Program", 800,850,100,50, "exit");
//		addObj(2, "This is Slide 2", 0,0,100,25, null);
//		addObj(1, "Go to Slide 2", 300,200,100,25, "2");
//		addObj(2, "Go to slide 1", 400,200,100,25, "1");
//		addObj("1", "PackagingMaterials/ImageFiles/defaultBG.png", "0", "0", "900", "900", "null");
//		addObj("1", "PackagingMaterials/ImageFiles/perfection.png", "0", "0", "900", "900", "null");
		
		container.removeAll();
		
		JPanel desc = new JPanel(new FlowLayout());
		JLabel info = new JLabel("<html>This SemiConsole allows you to add labels and buttons to your slides</html>");
		info.setFont(new Font("Serif", Font.ITALIC, 24));
		desc.add(info);
		container.add(info, BorderLayout.NORTH);
		
		JPanel miniCont = new JPanel();
		miniCont.setLayout(new BoxLayout(miniCont, BoxLayout.Y_AXIS));
		
		JPanel conSlide = new JPanel(new FlowLayout(FlowLayout.RIGHT)); 
		conSlide.add(new JLabel("Slide Number: ")); 
		conSlide.add(new JTextField(21)); 
		miniCont.add(conSlide);
		
		JPanel conText = new JPanel(new FlowLayout(FlowLayout.RIGHT)); 
		conText.add(new JLabel("Identifying Text: ")); 
		conText.add(new JTextField(21)); 
		miniCont.add(conText);
		
		JPanel conBounds = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		FlowLayout fl = new FlowLayout(FlowLayout.RIGHT); fl.setHgap(1);
		JPanel numBounds = new JPanel(fl);
		conBounds.add(new JLabel("Bounds (X,Y,Width,Height): ")); 
		numBounds.add(new JTextField("X", 5)); 
		numBounds.add(new JTextField("Y", 5)); 
		numBounds.add(new JTextField("Width", 5)); 
		numBounds.add(new JTextField("Height", 5));
		for(Component c : numBounds.getComponents()) {
			if(c instanceof JTextField) {
				((JTextField) c).addFocusListener(new FocusListener() {
					@Override
					public void focusGained(FocusEvent arg0) {
						c.setFont(c.getFont().deriveFont(Font.PLAIN));
						c.setForeground(Color.BLACK);
						try {
							Integer.parseInt(((JTextField) c).getText());
						} catch (Exception e) {
							((JTextField) c).setText("");
						}
					}

					@Override
					public void focusLost(FocusEvent arg0) {
						if(((JTextField) c).getText().equals("")) {
							c.setFont(c.getFont().deriveFont(Font.ITALIC));
							c.setForeground(Color.RED);
							((JTextField) c).setText("Error");
						}
					}
				});
			}
		}
		conBounds.add(numBounds);
		miniCont.add(conBounds);
		
		JPanel conCommand = new JPanel(new FlowLayout(FlowLayout.RIGHT)); 
		conCommand.add(new JLabel("Command (Default: null): ")); 
		JTextField jtf = new JTextField("null", 21);
		jtf.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {
				if(jtf.getText().equals("null")) {
					jtf.setText("");
				}
			}
			
			@Override
			public void focusLost(FocusEvent e) {
				if(jtf.getText().equals("")) {
					jtf.setText("null");
				}
			}
		});
		conCommand.add(jtf); 
		miniCont.add(conCommand);
		
		JPanel submit = new JPanel();
		ActionListener wriBu = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent ae) {
				switch(ae.getActionCommand()) {
					case "add":
						ArrayList<String> gtf = getTextFields(miniCont);
						if(!addObj(gtf.get(0), gtf.get(1), gtf.get(2), gtf.get(3), gtf.get(4), gtf.get(5), gtf.get(6))) {
							JFrame alert = new JFrame("ALERT! You have made an ERROR!");
							alert.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
							alert.getContentPane().add(new JLabel("<html><p>Please make sure that you have integer values for your Bounds (3rd row)</p></html>"));
							alert.setBackground(Color.RED);
							alert.setForeground(Color.YELLOW);
							alert.pack();
							alert.setVisible(true);
						} else {
							rdr.updateView();
							if(rdr.isShowing()) {
								rdr.setVisible(false);
								rdr.setVisible(true);
							}
							updateView();
							container.revalidate();
							container.repaint();
						}
						break;
					case "view":
						rdr.setVisible(!rdr.isShowing());
						break;
				}
			}
		};
		submit.setLayout(new BoxLayout(submit, BoxLayout.X_AXIS));
		submit.add(Box.createHorizontalGlue());
		JButton add = new JButton("Add");
		add.addActionListener(wriBu); add.setActionCommand("add");
		submit.add(add);
		submit.add(Box.createHorizontalGlue());
		JButton view = new JButton("Toggle View");
		view.addActionListener(wriBu); view.setActionCommand("view");
		submit.add(view);
		submit.add(Box.createHorizontalGlue());
		miniCont.add(submit);
		container.add(miniCont, BorderLayout.SOUTH);
		semiConsole.add(container);
	}
	
	/**
	 * add object to csv and save
	 * @param identifier
	 * @param type
	 * @param x
	 * @param y
	 * @param width
	 * @param height
	 */
	private boolean addObj(String slide, String identifier, String x, String y, String width, String height, String command) {
		try {
			String previous = getCsvContent();
			Integer.parseInt(x); Integer.parseInt(y); Integer.parseInt(width); Integer.parseInt(height);
			FileWriter fw = new FileWriter(csvPath);
			fw.write(slide + "," + identifier + "," + x + "," + y + "," + width + "," + height + "," + command + "\n" + previous);
			fw.close();
			return true;
		} catch (IOException ioe) {
			ioe.printStackTrace();
			System.exit(0);
		} catch (NumberFormatException nfe) {
			//nfe.printStackTrace();
		}
		return false;
	}
	
	/**
	 * get all jtextfield responses from a jpanel and its nested subpanels inside 
	 */
	private ArrayList<String> getTextFields(JPanel jp) {
		ArrayList<String> gtf = new ArrayList<String>();
		for(Component c : jp.getComponents()) {
			if(c instanceof JPanel) {
				for(String ce : getTextFields((JPanel) c)) {
					gtf.add(ce);
				}
			} else if(c instanceof JTextField) {
				gtf.add(((JTextField) c).getText());
			}
		}
		return gtf;
	}
	
	/**
	 * get csv content
	 */
	private String getCsvContent() {
		String output = "";
		try {
			new File(csvPath).createNewFile();
			BufferedReader br = new BufferedReader(new FileReader(csvPath));
			String line = "";
			while((line = br.readLine()) != null) {
				output+=line+"\n";
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return output;
	}
}
