package PackagingMaterials;
/**
 * 
 */

import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * @author Anmol Kapoor
 * @version 1.0
 */
public class Reader extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private String csvPath;
	private ArrayList<String> jCompList;
	private int currentSlide;
	private JPanel container;
	
	/**
	 * @param args N/A
	 */
	public static void main(String[] args) {
		new Reader(true);
	}
	
	/**
	 * Constructor
	 */
	public Reader(boolean visible) {
		super("CEFE Reader");
		if(visible) {
			setDefaultCloseOperation(EXIT_ON_CLOSE);
		} else {
			setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		}
		currentSlide = 1;
		jCompList = new ArrayList<String>();
		
		container = new JPanel();
		container.setLayout(null);
		updateView();
		
		setBackground(Color.WHITE);
		pack();
		setBounds(0,0,900,900+getInsets().top);
		setResizable(false);
		setVisible(visible);
	}
	
	/**
	 * setup the slide contents
	 */
	public void updateView() {
		jCompList.clear();
		csvPath = "PackagingMaterials/data.csv";
		BufferedReader br;
		String line = "";
		try {
			if(!new File(csvPath).exists()) {
				System.out.println("Please run the Writer Application before running the Reader Application.\nThank you for your understanding.");
				System.exit(0);
			}
			br = new BufferedReader(new FileReader(csvPath));
			while((line = br.readLine()) != null) {
				jCompList.add(line);
			}
			br.close();
		} catch (Exception e) {
			// e.printStackTrace();
		}
		
		container.removeAll();
		JLabel background = new JLabel(new ImageIcon(getBI("PackagingMaterials/ImageFiles/defaultBG.png")));
		background.setBounds(0,0,900,900);
		getContentPane().add(container);
		container.add(background);
		for(String details : jCompList) {
			String[] det = details.split(",");
			if (Integer.parseInt(det[0]) == currentSlide) {
				JLabel d;
				if(new File("PackagingMaterials/ImageFiles/" + det[1]).exists()) {
					d = new JLabel(new ImageIcon(getBI("PackagingMaterials/ImageFiles/" + det[1]).getScaledInstance(Integer.parseInt(det[4]), Integer.parseInt(det[5]), Image.SCALE_SMOOTH)));
				} else {
					d = new JLabel(det[1]);
				}
				d.setBounds(Integer.parseInt(det[2]), Integer.parseInt(det[3]), Integer.parseInt(det[4]), Integer.parseInt(det[5]));
				d.setOpaque(true);
				d.setBackground(Color.LIGHT_GRAY);
				background.add(d);
				background.repaint();
			}
		}
		background.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				exeCommand(e.getX(), e.getY());
			}
		});
		container.revalidate();
		container.repaint();
	}
	
	/**
	 * grab background image as bufferedimage
	 */
	private BufferedImage getBI(String path) {
		BufferedImage bimg = null;
    	try {
    		bimg = ImageIO.read(new FileInputStream(path));
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return bimg;
	}
	
	/**
	 * get JComponent from mouseclick
	 */
	private void exeCommand(int x, int y) {
		for(String details : jCompList) {
			String[] det = details.split(",");
			if(Integer.parseInt(det[0]) != currentSlide) {
				continue;
			}
			int det2 = Integer.parseInt(det[2]);
			int det3 = Integer.parseInt(det[3]);
			int det4 = Integer.parseInt(det[4]);
			int det5 = Integer.parseInt(det[5]);
			if(x >= det2 && x <= det4+det2 && y >= det3 && y <= det5+det3) {
				if(isNumeric(det[6])) {
					currentSlide = Integer.parseInt(det[6]);
				}
				switch(det[6]) {
					case "exit": System.exit(0); break;
				}
			}
		}
		updateView();
	}
	
	/**
	 * Check if a string is a number
	 */
	private boolean isNumeric(String num) {
		try {
			Integer.parseInt(num);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
